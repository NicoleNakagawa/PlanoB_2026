// Confere (e corrige, sem apagar nada) as tabelas e colunas que o site precisa.
//
// Roda sozinho toda vez que o servidor liga (app.js) e também pelo comando:
//   node scripts/migrarSuporteTutorial.js
//
// Por que existe: o banco do Railway pode ter sido criado por uma versão antiga do
// script_bd.sql. Se faltar uma coluna ou tabela (suporte, moderador, tutorial...),
// o site dá "erro interno" ou o chamado de suporte não chega ao moderador.
// Tudo aqui é seguro de rodar quantas vezes quiser.

async function colunaExiste(db, tabela, coluna) {
    const [linhas] = await db.query(
        `SELECT COUNT(*) AS total
         FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?`,
        [tabela, coluna]
    )
    return Number(linhas[0].total) > 0
}

async function tabelaExiste(db, tabela) {
    const [linhas] = await db.query(
        `SELECT COUNT(*) AS total
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?`,
        [tabela]
    )
    return Number(linhas[0].total) > 0
}

async function adicionarColuna(db, log, tabela, coluna, definicao) {
    if (await colunaExiste(db, tabela, coluna)) return false

    await db.query(`ALTER TABLE \`${tabela}\` ADD COLUMN \`${coluna}\` ${definicao}`)
    log(`  + ${tabela}.${coluna} criada`)
    return true
}

async function garantirEsquema(db, log = () => {}) {
    // ---------- Painel do moderador ----------
    await db.query(
        `CREATE TABLE IF NOT EXISTS moderador (
            id_moderador INT NOT NULL AUTO_INCREMENT,
            nome VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL,
            senha_hash VARCHAR(255) NOT NULL,
            nivel VARCHAR(30) DEFAULT 'padrao',
            foto_perfil VARCHAR(255) DEFAULT NULL,
            ativo TINYINT(1) NOT NULL DEFAULT 1,
            PRIMARY KEY (id_moderador),
            UNIQUE KEY uk_moderador_email (email)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    )

    await db.query(
        `CREATE TABLE IF NOT EXISTS moderacao_log (
            id_log INT NOT NULL AUTO_INCREMENT,
            id_moderador INT DEFAULT NULL,
            moderador_nome VARCHAR(100) NOT NULL,
            acao VARCHAR(50) NOT NULL,
            alvo_tipo VARCHAR(30) DEFAULT NULL,
            alvo_id INT DEFAULT NULL,
            detalhe VARCHAR(255) DEFAULT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id_log),
            KEY idx_log_criado (criado_em)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    )

    // ---------- Suporte ----------
    if (await tabelaExiste(db, 'suporte')) {
        await adicionarColuna(db, log, 'suporte', 'id_professor', 'INT DEFAULT NULL AFTER `id_aluno`')
        await adicionarColuna(db, log, 'suporte', 'tipo_usuario', "ENUM('aluno','professor') DEFAULT NULL AFTER `id_professor`")
        await adicionarColuna(db, log, 'suporte', 'assunto', 'VARCHAR(150) DEFAULT NULL')
        await adicionarColuna(db, log, 'suporte', 'status', "ENUM('aberto','em_atendimento','resolvido','fechado') NOT NULL DEFAULT 'aberto'")
        await adicionarColuna(db, log, 'suporte', 'resposta_nao_lida', 'TINYINT(1) NOT NULL DEFAULT 0')
        await adicionarColuna(db, log, 'suporte', 'atualizado_em', 'DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP')

        // Chamados antigos: quem tem id_aluno era aluno
        await db.query(`UPDATE suporte SET tipo_usuario = 'aluno' WHERE id_aluno IS NOT NULL AND tipo_usuario IS NULL`)

        // Chamado antigo podia ter id_aluno obrigatório; professor não tem id_aluno
        const [[colAluno]] = await db.query(
            `SELECT IS_NULLABLE FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'suporte' AND COLUMN_NAME = 'id_aluno'`
        )

        if (colAluno && colAluno.IS_NULLABLE === 'NO') {
            await db.query('ALTER TABLE suporte MODIFY id_aluno INT DEFAULT NULL')
            log('  ~ suporte.id_aluno agora aceita vazio (chamados de professor)')
        }

        const [fks] = await db.query(
            `SELECT COUNT(*) AS total
             FROM information_schema.TABLE_CONSTRAINTS
             WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'suporte' AND CONSTRAINT_NAME = 'fk_suporte_professor'`
        )

        if (Number(fks[0].total) === 0) {
            try {
                await db.query(
                    `ALTER TABLE suporte
                     ADD KEY idx_suporte_professor (id_professor),
                     ADD CONSTRAINT fk_suporte_professor FOREIGN KEY (id_professor) REFERENCES professor (id_professor)`
                )
                log('  + chave estrangeira suporte -> professor criada')
            } catch (err) {
                // A chave é só uma proteção extra; sem ela o suporte continua funcionando.
                log('  ! chave estrangeira suporte -> professor não criada: ' + err.message)
            }
        }
    } else {
        await db.query(
            `CREATE TABLE suporte (
                id_suporte INT NOT NULL AUTO_INCREMENT,
                id_aluno INT DEFAULT NULL,
                id_professor INT DEFAULT NULL,
                tipo_usuario ENUM('aluno','professor') DEFAULT NULL,
                nome VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                assunto VARCHAR(150) DEFAULT NULL,
                mensagem TEXT NOT NULL,
                status ENUM('aberto','em_atendimento','resolvido','fechado') NOT NULL DEFAULT 'aberto',
                resposta_nao_lida TINYINT(1) NOT NULL DEFAULT 0,
                criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id_suporte),
                KEY idx_suporte_aluno (id_aluno),
                KEY idx_suporte_professor (id_professor)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
        )
        log('  + tabela suporte criada')
    }

    await db.query(
        `CREATE TABLE IF NOT EXISTS suporte_mensagem (
            id_mensagem INT NOT NULL AUTO_INCREMENT,
            id_suporte INT NOT NULL,
            autor ENUM('usuario','moderador') NOT NULL,
            id_moderador INT DEFAULT NULL,
            nome_autor VARCHAR(100) NOT NULL,
            mensagem TEXT NOT NULL,
            criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id_mensagem),
            KEY idx_suporte_msg_chamado (id_suporte, criado_em),
            CONSTRAINT fk_suporte_msg_chamado FOREIGN KEY (id_suporte) REFERENCES suporte (id_suporte) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4`
    )

    // ---------- Tutorial de primeiro acesso ----------
    for (const tabela of ['aluno', 'professor']) {
        const criou = await adicionarColuna(db, log, tabela, 'tutorial_visto', 'TINYINT(1) NOT NULL DEFAULT 0')

        // Só quando a coluna acabou de ser criada: quem já tinha conta não precisa do tutorial
        if (criou) {
            await db.query(`UPDATE \`${tabela}\` SET tutorial_visto = 1`)
            log(`  ~ contas antigas de ${tabela} marcadas como "tutorial já visto"`)
        }
    }
}

module.exports = { garantirEsquema, colunaExiste, tabelaExiste }
