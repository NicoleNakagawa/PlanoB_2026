// =====================================================================
// Migração: suporte com respostas + tutorial de primeiro acesso + painel do moderador
//
// Rode quando quiser (pode rodar de novo sem problema, ele confere antes):
//   node scripts/migrarSuporteTutorial.js
//
// O site já faz essa mesma conferência sozinho ao ligar (veja app/utils/garantirEsquema.js);
// este comando serve para rodar na hora e ver o que foi corrigido.
// =====================================================================

const db = require('../app/config/pool_conexoes')
const { garantirEsquema } = require('../app/utils/garantirEsquema')

console.log('Conferindo o banco...')

garantirEsquema(db, mensagem => console.log(mensagem))
    .then(() => {
        console.log('Banco conferido. Nada mais a corrigir.')
        process.exit(0)
    })
    .catch(err => {
        console.error('Erro na migração:', err.message)
        process.exit(1)
    })
